import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
@Component({
  selector: 'app-department-detail',
  template: `
    <h3>
    You selected department with id = {{departmentId}}
    </h3>
    <router-outlet></router-outlet>
    <p>
    <button (click)="showOverview()">Overview</button>
    <button (click)="showContact()">Contact</button>
    </p>
  `,
  styles: []
})
export class DepartmentDetailComponent implements OnInit {
  
  public departmentId;
  constructor(private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    let id=this.route.snapshot.params['id'];
    this.departmentId=id;
  }
  showOverview()
  {
    this.router.navigate(['overview'],{relativeTo:this.route})
  }
showContact()
{
  this.router.navigate(['contact'],{relativeTo:this.route})
 
}
}
