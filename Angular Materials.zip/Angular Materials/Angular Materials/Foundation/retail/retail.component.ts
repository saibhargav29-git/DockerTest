import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retail',
  templateUrl: './retail.component.html',
  styleUrls: ['./retail.component.css']
})
export class RetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public fname;
  
  public lname;
    
  public welcomeText="hello";
  
public siteUrl=window.location.href;
public count=0;
public DOJ = new Date();


public person = {
  "firstName":"John",
  "lastName":"Doe"
  }
print(obj)
{
  console.log(obj);
}

showCount()
{
  return ++this.count;
}

showMsg()
{
alert("welcome");
}

greetUser()
{
return "hello"+this.fname;
}

}
