import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { DataComponent } from './data/data.component';
import { ChildComponent } from './child/child.component';
import { RetailComponent } from './retail/retail.component';
import { TravelComponent } from './travel/travel.component';


@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    DataComponent,
    ChildComponent,
    RetailComponent,
    TravelComponent,
   ],
  imports: [
    BrowserModule,
    FormsModule
 
 
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
