import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
  <h2>Name:<span style="color:green;font-size:18px">{{employeeName}}</span></h2>
  <h2>City:<span style="color:green;font-size:18px">{{employeeCity}}</span></h2>
  <h2>Salary:<span style="color:green;font-size:18px">{{employeeSalary}}</span></h2>
  <button (click)="emitSendRecordEvent()">Click Here</button>
  <hr/>

  `,
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  @Input() employeeName:string;
  @Input() employeeCity:string;
  @Input() employeeSalary:number;

  @Output() sendRecord:EventEmitter<any> =new EventEmitter();
  constructor() { }

  ngOnInit() {
  }


  public emitSendRecordEvent()
  {
    let selectedEmployeeObj:any={
    selectedName:this.employeeName,
    selectedCity:this.employeeCity,
    selectedSalary:this.employeeSalary
    };
    this.sendRecord.emit(selectedEmployeeObj);
  }
}
