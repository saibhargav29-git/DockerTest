import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second',
  template: `
    {{fname}}
  `,
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
 fname:string="Jana";
}
