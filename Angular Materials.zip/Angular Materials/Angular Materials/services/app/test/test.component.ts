import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
 <h2>
 {{"Hello " +parentData}}
 </h2>
 <button (click)="fireEvent()">Send Event</button>
  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
 @Input()
 public parentData;

 @Output()
 public childEvent =new EventEmitter();
  constructor() { }

  fireEvent()
  {
    this.childEvent.emit("Hello World");
  }

  ngOnInit() {
  }

}
