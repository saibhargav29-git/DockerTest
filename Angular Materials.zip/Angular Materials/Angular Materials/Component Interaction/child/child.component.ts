import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  template: `
    <h2>
    {{"Hello" +parentData}}
    </h2>
    <button (click) ="fireEvent()">Send Event</button>
  `,
  styles: []
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
@Input()
public parentData;

@Output()
public childEvent =new EventEmitter();

fireEvent()
{
  this.childEvent.emit("hello world");
}
}
